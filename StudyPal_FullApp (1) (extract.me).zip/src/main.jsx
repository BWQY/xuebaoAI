import React from 'react';
import ReactDOM from 'react-dom/client';
import StudyPalApp from './App';

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <StudyPalApp />
  </React.StrictMode>
);