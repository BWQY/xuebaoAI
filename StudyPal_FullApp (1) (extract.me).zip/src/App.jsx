import React, { useState } from "react";
import { Tabs, Tab } from "@mui/material";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export default function StudyPalApp() {
  const [tab, setTab] = useState(0);
  const [mood, setMood] = useState("");
  const [studyGoal, setStudyGoal] = useState("");
  const [focusTime, setFocusTime] = useState(0);
  const [message, setMessage] = useState("");

  const handleTabChange = (e, newValue) => setTab(newValue);

  const handleStartFocus = () => {
    setMessage("专注模式启动中……加油！💪");
    setTimeout(() => {
      setFocusTime((t) => t + 25);
      setMessage("🎉 专注25分钟完成！奖励已解锁！");
    }, 2000);
  };

  return (
    <div className="p-4 max-w-3xl mx-auto">
      <h1 className="text-3xl font-bold mb-2 text-center">StudyPal 学伴AI</h1>
      <p className="text-center text-muted mb-4">你的智能学习伙伴</p>

      <Tabs value={tab} onChange={handleTabChange} centered>
        <Tab label="🏠 首页" />
        <Tab label="📅 学习计划" />
        <Tab label="🧘 情绪支持" />
        <Tab label="📂 学习资源" />
        <Tab label="📊 我的数据" />
      </Tabs>

      {tab === 0 && (
        <Card className="mt-4">
          <CardContent>
            <h2 className="text-xl font-semibold mb-2">欢迎回来！</h2>
            <p>本周专注时长：{focusTime} 分钟</p>
          </CardContent>
        </Card>
      )}

      {tab === 1 && (
        <Card className="mt-4">
          <CardContent>
            <h2 className="text-xl font-semibold mb-2">📅 智能学习计划</h2>
            <Input
              placeholder="请输入今天的学习目标..."
              value={studyGoal}
              onChange={(e) => setStudyGoal(e.target.value)}
            />
            <Button className="mt-2" onClick={() => alert("学习计划已设定！")}>保存计划</Button>
          </CardContent>
        </Card>
      )}

      {tab === 2 && (
        <Card className="mt-4">
          <CardContent>
            <h2 className="text-xl font-semibold mb-2">🧘 情绪与心理支持</h2>
            <Input
              placeholder="今天的心情是？😊😐😢"
              value={mood}
              onChange={(e) => setMood(e.target.value)}
            />
            <p className="mt-2">每日鼓励：你正在进步，每一步都值得赞赏！</p>
          </CardContent>
        </Card>
      )}

      {tab === 3 && (
        <Card className="mt-4">
          <CardContent>
            <h2 className="text-xl font-semibold mb-2">📂 学习资源中心</h2>
            <ul className="list-disc ml-6">
              <li>数学练习册（PDF）</li>
              <li>优质讲解视频：高中物理</li>
              <li>笔记分享：作文技巧</li>
            </ul>
          </CardContent>
        </Card>
      )}

      {tab === 4 && (
        <Card className="mt-4">
          <CardContent>
            <h2 className="text-xl font-semibold mb-2">📊 我的数据</h2>
            <p>累计学习目标：{studyGoal || "暂无记录"}</p>
            <p>本周情绪记录：{mood || "未记录"}</p>
            <p>专注总时长：{focusTime} 分钟</p>
          </CardContent>
        </Card>
      )}

      <div className="mt-6 text-center">
        <Button onClick={handleStartFocus}>开启专注模式</Button>
        {message && <p className="mt-2 text-green-600">{message}</p>}
      </div>
    </div>
  );
}